<?php
defined('BASEPATH') or exit('No direct script access allowed');

$config['upload_path'] = 'assets/image/lampiran/';
$config['allowed_types'] = 'pdf|doc|docx|xls|xlsx|ppt|pptx|jpg|jpeg|png';
$config['max_size'] = 102400;