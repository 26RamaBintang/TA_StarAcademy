<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Auth extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
    }
    public function index()
    {
        $this->form_validation->set_rules('username', 'Username', 'required|trim');
        $this->form_validation->set_rules('passwd', 'Passwd', 'required|trim');

        if ($this->form_validation->run() == false) {
            $data['title'] = 'StarAcademy | Masuk';
            $this->load->view('templates/auth_header', $data);
            $this->load->view('auth/masuk');
            $this->load->view('templates/auth_footer');
        } else {
            // validasi berhasil
            $this->_masuk();
        }
    }

    private function _masuk()
    {
        $username = $this->input->post('username');
        $passwd = $this->input->post('passwd');

        $user = $this->db->get_where('tb_user', ['username' => $username])->row_array();

        // var_dump($user);
        // die;


        // jika usernya ada
        if ($user) {
            // cek password
            if (password_verify($passwd, $user['passwd'])) {
                $data = [
                    'id_user' => $user['id_user'],
                    'username' => $user['username'],
                    'status' => $user['status']
                ];
                if ($user['status'] == 'Siswa') {
                    $this->session->set_userdata($data);
                    redirect('siswa');
                } else if ($user['status'] == 'Guru') {
                    $this->session->set_userdata($data);
                    redirect('guru');
                } else {
                    $this->session->set_userdata($data);
                    redirect('admin');
                }
            } else {
                $this->session->set_flashdata('notif', '<div class="alert alert-danger" role="alert">Password Salah !</div>');
                redirect('auth');
            }
        } else {
            $this->session->set_flashdata('notif', '<div class="alert alert-danger" role="alert">Username Belum Terdaftar !</div>');
            redirect('auth');
        }
    }

    public function daftar()
    {

        $this->form_validation->set_rules('username', 'Username', 'required|trim|is_unique[tb_user.username]', [
            'is_unique' => 'Username Sudah Digunakan !'
        ]);
        $this->form_validation->set_rules('passwd1', 'Passwd', 'required|trim|min_length[8]|matches[passwd2]', [
            'matches' => 'Password Tidak Cocok !',
            'min_length' => 'Password Minimal Memiliki 8 Karakter !'
        ]);
        $this->form_validation->set_rules('passwd2', 'Passwd', 'required|trim|matches[passwd1]', [
            'matches' => 'Password Tidak Cocok !',
        ]);
        $this->form_validation->set_rules('status', 'Status', 'required|trim');

        $id_user_unique = false;
        while (!$id_user_unique) {
            $id_user = substr(uniqid(), -9);
            $query = $this->db->get_where('tb_user', array('id_user' => $id_user));
            if ($query->num_rows() == 0) {
                $id_user_unique = true;
            }
        }

        if ($this->form_validation->run() == false) {
            $data['title'] = 'StarAcademy | Daftar';
            $this->load->view('templates/auth_header', $data);
            $this->load->view('auth/daftar');
            $this->load->view('templates/auth_footer');
        } else {
            $data = [
                'id_user' => $id_user,
                'username' => htmlspecialchars($this->input->post('username', true)),
                'passwd' => password_hash($this->input->post('passwd1'), PASSWORD_DEFAULT),
                'status' => $this->input->post('status'),
            ];

            $this->db->insert('tb_user', $data);
            $this->session->set_flashdata('notif', '<div class="alert alert-success" role="alert">Akun Berhasil Terdaftar!</div>');
            redirect('auth');
        }
    }

    public function keluar()
    {

        $this->session->unset_userdata('username');
        $this->session->unset_userdata('status');
        $this->session->unset_userdata('id_user');

        $this->session->set_flashdata('notif', '<div class="alert alert-success" role="alert">Anda Telah Keluar !</div>');
        redirect('auth');
    }
}
