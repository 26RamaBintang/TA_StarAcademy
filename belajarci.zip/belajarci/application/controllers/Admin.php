<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        is_logged_in();
    }

    public function index()
    {
        $data['title'] = 'StarAcademy | Dashboard';
        $data['user'] = $this->db->get_where('tb_user', ['id_user' => $this->session->userdata('id_user')])->row_array();

        $this->load->view('admin/dashboard', $data);
    }

    public function kelola_guru()
    {
        $data['user'] = $this->db->get_where('tb_user', ['id_user' => $this->session->userdata('id_user')])->row_array();

        $data['list'] = $this->db->get_where('tb_user', ['status' => 'Guru'])->result_array();

        $data['title'] = 'StarAcademy | Kelola Guru';
        $this->load->view('admin/kelola_guru', $data);
    }

    public function kelola_kelas()
    {
        $data['user'] = $this->db->get_where('tb_user', ['id_user' => $this->session->userdata('id_user')])->row_array();

        $data['list'] = $this->db->get_where('tb_kelas', ['id_kelas'])->result_array();

        $data['title'] = 'StarAcademy | Kelola Kelas';
        $this->load->view('admin/kelola_kelas', $data);
    }

    public function isi_kelas($id_user)
    {
        $data['user'] = $this->db->get_where('tb_user', ['id_user' => $this->session->userdata('id_user')])->row_array();

        $data['list'] = $this->db->get_where('tb_kelas', ['id_kelas' => $id_user])->result_array();

        $data['title'] = 'StarAcademy | Kelola Kelas';
        $this->load->view('admin/isi_kelas', $data);
    }

    public function kelola_siswa($id_kelas)
    {
        $data['user'] = $this->db->get_where('tb_user', ['id_user' => $this->session->userdata('id_user')])->row_array();

        $data['list'] = $this->db->get_where('tb_anggota', ['id_kelas' => $id_kelas])->result_array();

        $data['title'] = 'StarAcademy | Kelola Siswa';
        $this->load->view('admin/kelola_siswa', $data);
    }

    public function kelola_tugas($id_kelas)
    {
        $data['user'] = $this->db->get_where('tb_user', ['id_user' => $this->session->userdata('id_user')])->row_array();

        $data['list'] = $this->db
        ->order_by('tgl_buat', 'desc') // Urutkan berdasarkan waktu_pembuatan secara descending (terbaru paling atas)
        ->get_where('tb_tugas', ['id_kelas' => $id_kelas])
        ->result_array();
    
        $data['title'] = 'StarAcademy | Kelola Tugas';
        $this->load->view('admin/kelola_tugas', $data);
    }

    public function kelola_komen($id_kelas)
    {
        $data['user'] = $this->db->get_where('tb_user', ['id_user' => $this->session->userdata('id_user')])->row_array();

        $data['list'] = $this->db
        ->order_by('tanggal', 'desc') // Urutkan berdasarkan waktu_pembuatan secara descending (terbaru paling atas)
        ->get_where('tb_komen', ['id_kelas' => $id_kelas])
        ->result_array();
    
        $data['title'] = 'StarAcademy | Kelola Komen';
        $this->load->view('admin/kelola_komen', $data);
    }

    public function delete($id_user)
    {

        $this->db->where('id_user', $id_user);
        $this->db->delete('tb_user');

        $this->session->set_flashdata('notif', '<div class="alert alert-success w-25 mt-2" role="alert">Data Berhasil Dihapus !</div>');
        redirect('admin/kelola_guru');
    }

    public function DeleteKelas($id_kelas)
    {
        // Hapus terlebih dahulu entri dari tabel 'tb_anggota'
        $this->db->where('id_kelas', $id_kelas);
        $this->db->delete('tb_anggota');

        // Setelah entri di 'tb_anggota' dihapus, hapus dari 'tb_kelas'
        $this->db->where('id_kelas', $id_kelas);
        $this->db->delete('tb_kelas');

        $this->session->set_flashdata('notif', '<div class="alert alert-success w-25 mt-2" role="alert">Data Berhasil Dihapus !</div>');
        redirect('admin/kelola_kelas');
    }

    public function DeleteTugas($id_tugas)
    {
        // Hapus terlebih dahulu entri dari tabel 'tb_anggota'
        $this->db->where('id_tugas', $id_tugas);
        $this->db->delete('tb_tugas');

        $this->session->set_flashdata('notif', '<div class="alert alert-success w-25 mt-2" role="alert">Data Berhasil Dihapus !</div>');
        redirect($_SERVER['HTTP_REFERER']);
    }

    public function DeleteSiswa($id_anggota)
    {
        // Hapus terlebih dahulu entri dari tabel 'tb_anggota'
        $this->db->where('id_user', $id_anggota);
        $this->db->delete('tb_anggota');

        $this->session->set_flashdata('notif', '<div class="alert alert-success w-25 mt-2" role="alert">Data Berhasil Dihapus !</div>');
        redirect($_SERVER['HTTP_REFERER']);
    }
}

/* End of file Siswa.php and path \application\controllers\Siswa.php */
