<?php

use function PHPSTORM_META\type;

defined('BASEPATH') or exit('No direct script access allowed');

class guru extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        is_logged_in();
    }

    public function index()
    {
        $data['user'] = $this->db->get_where('tb_user', ['id_user' => $this->session->userdata('id_user')])->row_array();

        $data['list'] = $this->db->get_where('tb_kelas', ['id_user' => $this->session->userdata('id_user')])->result_array();

        $data['title'] = 'StarAcademy | Beranda';
        $this->load->view('guru/header_beranda', $data);
        $this->load->view('guru/beranda', $data);
    }


    public function edit()
    {
        $data['user'] = $this->db->get_where('tb_user', ['id_user' => $this->session->userdata('id_user')])->row_array();

        $data['title'] = 'StarAcademy | Beranda';

        $this->form_validation->set_rules('username', 'Username', 'required|trim');

        if ($this->form_validation->run() == false) {
            $this->load->view('guru/header_beranda', $data);
            $this->load->view('guru/beranda', $data);
        } else {
            $username = $this->input->post('username');
            $id_user = $this->input->post('id_user');

            $this->db->set('username', $username);
            $this->db->where('id_user', $id_user);
            $this->db->update('tb_user');

            $this->session->set_flashdata('notif', '<div class="alert alert-success" role="alert">Profile Berhasil Diubah !</div>');
            redirect('guru');
        }
    }

    public function BuatKelas()
    {
        $this->form_validation->set_rules('nama_kelas', 'Nama Kelas', 'required|trim');
        $this->form_validation->set_rules('mata_pelajaran', 'Mata Pelajaran', 'required|trim');

        if ($this->form_validation->run() == false) {
            $data['title'] = 'StarAcademy | Beranda';
            $this->load->view('guru/header_beranda', $data);
            $this->load->view('guru/beranda', $data);
        } else {
            $user = $this->db->get_where('tb_user', ['id_user' => $this->session->userdata('id_user')])->row_array();

            $id_kelas_unique = false;
            while (!$id_kelas_unique) {
                $id_kelas = substr(uniqid(), -7);
                $query = $this->db->get_where('tb_kelas', array('id_kelas' => $id_kelas));
                if ($query->num_rows() == 0) {
                    $id_kelas_unique = true;
                }
            }

            $data = array(
                'id_kelas' => $id_kelas,
                'id_user' => $user['id_user'], // Ubah menjadi $user['id_user']
                'nama_kelas' => htmlspecialchars($this->input->post('nama_kelas', true)),
                'mata_pelajaran' => htmlspecialchars($this->input->post('mata_pelajaran', true)),
            );

            $this->db->insert('tb_kelas', $data);
            $this->session->set_flashdata('notif', '<div class="alert alert-success" role="alert">Kelas Berhasil Dibuat !</div>');
            redirect('guru');
        }
    }

    public function kelas($id_kelas = null)
    {
        // Set sesi hanya jika id_kelas ada dan bukan null
        if ($id_kelas !== null) {
            // Pastikan id_kelas yang diset di sesi sesuai dengan yang diharapkan
            $sesi_data = array('id_kelas' => $id_kelas);
            $this->session->set_userdata('kelas', $sesi_data);
        }

        // Ambil data sesuai dengan session 'kelas'
        $kelas_id = $this->session->userdata('kelas');

        if ($kelas_id && isset($kelas_id['id_kelas'])) {
            // Pastikan nilai 'id_kelas' yang diambil dari sesi digunakan dengan benar
            $id_kelas = $kelas_id['id_kelas'];
            $this->db->where('id_kelas', $id_kelas);
            $query = $this->db->get('tb_kelas');
            $data['kelas'] = $query->result();

            $data['user'] = $this->db->get_where('tb_user', ['id_user' => $this->session->userdata('id_user')])->row_array();

            $id_kelas = $kelas_id['id_kelas'];
            $this->db->where('id_kelas', $id_kelas);
            $this->db->order_by('tgl_buat', 'DESC'); // Menambahkan pengurutan berdasarkan kolom waktu_tugas secara descending
            $query = $this->db->get('tb_tugas');
            $data['tugas'] = $query->result();


            $data['title'] = 'StarAcademy | Kelas';
            $this->load->view('guru/header_kelas', $data);
            $this->load->view('guru/kelas', $data);
        }
    }


    public function BuatTugas($id_kelas = null)
    {
        if ($id_kelas !== null) {
            // Pastikan id_kelas yang diset di sesi sesuai dengan yang diharapkan
            $sesi_data = array('id_kelas' => $id_kelas);
            $this->session->set_userdata('kelas', $sesi_data);
        }

        $kelas_id = $this->session->userdata('kelas');

        if ($kelas_id && isset($kelas_id['id_kelas'])) {
            $id_kelas = $kelas_id['id_kelas'];

            $this->db->where('id_kelas', $id_kelas);
            $query = $this->db->get('tb_kelas');
            $data['kelas'] = $query->result();

            $data['user'] = $this->db->get_where('tb_user', ['id_user' => $this->session->userdata('id_user')])->row_array();

            $data['title'] = 'StarAcademy | Kelas';

            $this->form_validation->set_rules('judul_tugas', 'Judul Tugas', 'required|trim');
            $this->form_validation->set_rules('petunjuk', 'Petunjuk', 'required|trim');
            $this->form_validation->set_rules('poin', 'Poin', 'required|numeric');

            if ($this->form_validation->run() == false) {
                $data['title'] = 'StarAcademy | Buat Tugas';
                $this->load->view('guru/buat_tugas', $data);
            } else {
                $lampiran = $_FILES['upload'];

                $config['upload_path'] = 'assets/image/lampiran/';
                $config['allowed_types'] = 'pdf|doc|docx|xls|xlsx|ppt|pptx|jpg|jpeg|png';
                $config['max_size'] = 102400;

                $this->load->library('upload', $config);

                $uploaded_files = array();
                $error_flag = false;

                foreach ($lampiran['name'] as $key => $filename) {
                    $_FILES['upload[]']['name']     = $lampiran['name'][$key];
                    $_FILES['upload[]']['type']     = $lampiran['type'][$key];
                    $_FILES['upload[]']['tmp_name'] = $lampiran['tmp_name'][$key];
                    $_FILES['upload[]']['error']    = $lampiran['error'][$key];
                    $_FILES['upload[]']['size']     = $lampiran['size'][$key];

                    if (!$this->upload->do_upload('upload[]')) {
                        $error_flag = true;
                        echo $this->upload->display_errors();
                        break;  // Stop the loop if any error occurs
                    } else {
                        $uploaded_files[] = $this->upload->data('file_name');
                    }
                }

                if (!$error_flag) {
                    $judul_tugas = $this->input->post('judul_tugas', true);
                    $petunjuk = $this->input->post('petunjuk', true);
                    $tenggat_waktu = $this->input->post('tenggat_waktu', true);
                    $poin = $this->input->post('poin', true);
                    $tgl_buat = date('Y-m-d H:i:s');

                    $id_tugas_unique = false;
                    while (!$id_tugas_unique) {
                        $id_tugas = substr(uniqid(), -10);
                        $query = $this->db->get_where('tb_tugas', array('id_tugas' => $id_tugas));

                        if ($query->num_rows() == 0) {
                            $id_tugas_unique = true;
                        }
                    }

                    $insert_data = array(
                        'id_tugas' => $id_tugas,
                        'id_kelas' => $id_kelas,
                        'judul_tugas' => $judul_tugas,
                        'petunjuk' => $petunjuk,
                        'lampiran' => implode(',', $uploaded_files),
                        'poin' => $poin,
                        'tenggat' => $tenggat_waktu,
                        'tgl_buat' => $tgl_buat,
                    );

                    $this->db->insert('tb_tugas', $insert_data);
                    redirect('guru/kelas');
                }
            }
        }
    }


    public function tampil_tugas($id_tugas = null, $id_kelas = null)
    {
        // Set sesi hanya jika id_tugas ada dan bukan null
        if ($id_tugas !== null) {
            $sesi_data = array('id_tugas' => $id_tugas);
            $this->session->set_userdata('id_tugas', $sesi_data);
        }

        // Set sesi hanya jika id_kelas ada dan bukan null
        if ($id_kelas !== null) {
            $sesi_data_kelas = array('id_kelas' => $id_kelas);
            $this->session->set_userdata('kelas', $sesi_data_kelas);
        }

        // Ambil data sesuai dengan session 'kelas'
        $kelas_id = $this->session->userdata('kelas');

        if ($kelas_id && isset($kelas_id['id_kelas'])) {
            // Ambil ID kelas dari sesi
            $id_kelas = $kelas_id['id_kelas'];
            $id_tugas = $this->session->userdata('id_tugas')['id_tugas'];

            $data['user'] = $this->db->get_where('tb_user', ['id_user' => $this->session->userdata('id_user')])->row_array();
            $data['kelas'] = $this->db->get_where('tb_kelas', ['id_kelas' => $id_kelas])->row_array();
            $data['tugas'] = $this->db->get_where('tb_tugas', ['id_tugas' => $id_tugas])->row_array();

            $data['tugas']['lampiran'] = explode(',', $data['tugas']['lampiran']);

            $iconDir = 'assets/image/icons/';

            // Tentukan ikon berdasarkan ekstensi file
            $iconMapping = [
                'pdf' => 'pdf.png',
                'doc' => 'word.png',
                'docx' => 'word.png',
                'ppt' => 'ppt.png',
                'pptx' => 'ppt.png',
                'xls' => 'excel.png',
                'xlsx' => 'excel.png',
                // tambahkan lebih banyak jenis file jika diperlukan
            ];

            // Tambahkan ikon ke setiap lampiran
            // Tambahkan ikon ke setiap lampiran
            foreach ($data['tugas']['lampiran'] as &$lampiran) {
                $fileExtension = pathinfo($lampiran, PATHINFO_EXTENSION);
                $icon = isset($iconMapping[$fileExtension]) ? $iconMapping[$fileExtension] : 'icon-default.png';

                // Ganti bagian ini untuk menggunakan gambar dari folder assets/image/lampiran
                $lampiranPath = 'assets/image/lampiran/' . $lampiran;
                $icon = file_exists($lampiranPath) ? base_url($lampiranPath) : base_url($iconDir . $icon);

                // Tambahkan key "type" berdasarkan ekstensi file
                $lampiran = ['nama' => $lampiran, 'icon' => $icon, 'type' => 'file'];
            }

            $data['title'] = 'StarAcademy | Tugas';
            $this->load->view('guru/header_kelas', $data);
            // var_dump($data);
            $this->load->view('guru/tampil_tugas', $data);
        }
    }

    public function jawaban($id_tugas = null, $id_kelas = null)
    {
        // Set sesi hanya jika id_tugas ada dan bukan null
        if ($id_tugas !== null) {
            $sesi_data = array('id_tugas' => $id_tugas);
            $this->session->set_userdata('id_tugas', $sesi_data);
        }

        // Set sesi hanya jika id_kelas ada dan bukan null
        if ($id_kelas !== null) {
            $sesi_data_kelas = array('id_kelas' => $id_kelas);
            $this->session->set_userdata('kelas', $sesi_data_kelas);
        }

        // Ambil data sesuai dengan session 'kelas'
        $kelas_id = $this->session->userdata('kelas');

        if ($kelas_id && isset($kelas_id['id_kelas'])) {
            // Ambil ID kelas dari sesi
            $id_kelas = $kelas_id['id_kelas'];
            $id_tugas = $this->session->userdata('id_tugas')['id_tugas'];

            $data['user'] = $this->db->get_where('tb_user', ['id_user' => $this->session->userdata('id_user')])->row_array();
            $data['kelas'] = $this->db->get_where('tb_kelas', ['id_kelas' => $id_kelas])->row_array();
            $data['tugas'] = $this->db->get_where('tb_tugas', ['id_tugas' => $id_tugas])->row_array();

            $id_kelas = $kelas_id['id_kelas'];
            $this->db->where('id_kelas', $id_kelas);
            $query = $this->db->get('tb_anggota');
            $data['anggota'] = $query->result();

            $data['title'] = 'StarAcademy | Tugas';
            $this->load->view('guru/header_kelas', $data);
            // var_dump($data);
            $this->load->view('guru/jawaban', $data);
        }
    }

    public function edit_tugas($id_tugas = null)
    {
        $kelas_id = $this->session->userdata('kelas');

        if ($kelas_id && isset($kelas_id['id_kelas'])) {
            // Retrieve existing task data if $id_tugas is provided
            $existing_task = null;
            if ($id_tugas !== null) {
                $existing_task = $this->db->get_where('tb_tugas', array('id_tugas' => $id_tugas))->row_array();
            }

            $data['kelas'] = $this->db->get_where('tb_kelas', array('id_kelas' => $kelas_id['id_kelas']))->result();
            $data['user'] = $this->db->get_where('tb_user', ['id_user' => $this->session->userdata('id_user')])->row_array();
            $data['title'] = 'StarAcademy | Kelas';

            $this->form_validation->set_rules('judul_tugas', 'Judul Tugas', 'required|trim');
            $this->form_validation->set_rules('petunjuk', 'Petunjuk', 'required|trim');
            // Add more validation rules for other fields

            if ($this->form_validation->run() == false) {
                // If form is not submitted, load the view with existing task data if available
                $data['title'] = ($id_tugas !== null) ? 'StarAcademy | Edit Tugas' : 'StarAcademy | Buat Tugas';
                $data['existing_task'] = $existing_task;
                $this->load->view('guru/edit_tugas', $data);
            } else {
                // If form is submitted, process the data

                $id_kelas = $kelas_id['id_kelas'];
                $judul_tugas = $this->input->post('judul_tugas', true);
                $petunjuk = $this->input->post('petunjuk', true);
                // Get other form inputs

                $insert_data = array(
                    'id_kelas' => $id_kelas,
                    'judul_tugas' => htmlspecialchars($judul_tugas),
                    'petunjuk' => htmlspecialchars($petunjuk),
                    // Add other fields
                );

                // Update existing task if $id_tugas is provided
                if ($id_tugas !== null) {
                    $this->db->where('id_tugas', $id_tugas);
                    $this->db->update('tb_tugas', $insert_data);
                    $this->session->set_flashdata('notif', '<div class="alert alert-success" role="alert">Tugas Berhasil Diubah !</div>');
                } else {
                    // Insert new task
                    $this->db->insert('tb_tugas', $insert_data);
                    $this->session->set_flashdata('notif', '<div class="alert alert-success" role="alert">Tugas Berhasil Dibuat !</div>');
                }

                redirect('guru/tampil_tugas');
            }
        } else {
            // Handle case when there is no valid session
            $data['kelas'] = array();
            $data['title'] = 'StarAcademy | Kelas Tidak Ditemukan';

            $this->load->view('guru/header_beranda', $data);
            $this->load->view('guru/beranda', $data);
        }
    }


    public function komen($id_kelas = null)
    {
        if ($id_kelas !== null) {
            // Pastikan id_kelas yang diset di sesi sesuai dengan yang diharapkan
            $sesi_data = array('id_kelas' => $id_kelas);
            $this->session->set_userdata('kelas', $sesi_data);
        }

        $kelas_id = $this->session->userdata('kelas');

        if ($kelas_id && isset($kelas_id['id_kelas'])) {
            // Pastikan nilai 'id_kelas' yang diambil dari sesi digunakan dengan benar
            $id_kelas = $kelas_id['id_kelas'];
            $this->db->where('id_kelas', $id_kelas);
            $query = $this->db->get('tb_kelas');
            $data['kelas'] = $query->result();

            $id_kelas = $kelas_id['id_kelas'];
            $this->db->where('id_kelas', $id_kelas);
            $this->db->order_by('tanggal', 'DESC');
            $query = $this->db->get('tb_komen');
            $data['komen'] = $query->result();

            $data['user'] = $this->db->get_where('tb_user', ['id_user' => $this->session->userdata('id_user')])->row_array();

            $data['title'] = 'StarAcademy | Kelas';

            $this->form_validation->set_rules('komen', 'Komen', 'required|trim');
            if ($this->form_validation->run() == false) {
                $data['title'] = 'StarAcademy | Komen';
                $this->load->view('guru/header_kelas', $data);
                $this->load->view('guru/komen', $data);
            } else {
                $kelas_id = $this->session->userdata('kelas');

                if ($kelas_id && isset($kelas_id['id_kelas'])) {
                    $id_kelas = $kelas_id['id_kelas'];

                    // Mengambil data dari formulir
                    $komen = $this->input->post('komen', true);
                    $pengirim = $this->input->post('pengirim', true);
                    $username = $this->input->post('nama_pengirim', true);
                    $tanggal = date('Y-m-d H:i:s');

                    // Menghasilkan id_tugas yang unik
                    $id_tugas_unique = false;
                    while (!$id_tugas_unique) {
                        $id_tugas = substr(uniqid(), -10);
                        $query = $this->db->get_where('tb_tugas', array('id_tugas' => $id_tugas));
                        if ($query->num_rows() == 0) {
                            $id_tugas_unique = true;
                        }
                    }

                    // Menyiapkan data untuk di-insert ke database
                    $insert_data = array(
                        'id_kelas' => $id_kelas,
                        'id_user' => $pengirim,
                        'username' => $username,
                        'komen' => htmlspecialchars($komen),
                        'tanggal' => $tanggal,
                    );

                    // Memanggil model untuk melakukan insert ke database
                    $this->db->insert('tb_komen', $insert_data);

                    // Menampilkan notifikasi dan mengarahkan kembali ke halaman kelas
                    redirect('guru/komen');
                }
            }
        } else {
            // Tindakan jika tidak ada sesi yang dipilih
            $data['kelas'] = array();
            $data['title'] = 'StarAcademy | Kelas Tidak Ditemukan';

            $this->load->view('guru/header_beranda', $data);
            $this->load->view('guru/beranda', $data);
        }
    }

    public function vidbel($id_kelas = null)
    {
        // Set sesi hanya jika id_kelas ada dan bukan null
        if ($id_kelas !== null) {
            // Pastikan id_kelas yang diset di sesi sesuai dengan yang diharapkan
            $sesi_data = array('id_kelas' => $id_kelas);
            $this->session->set_userdata('kelas', $sesi_data);
        }

        // Ambil data sesuai dengan session 'kelas'
        $kelas_id = $this->session->userdata('kelas');

        if ($kelas_id && isset($kelas_id['id_kelas'])) {
            // Pastikan nilai 'id_kelas' yang diambil dari sesi digunakan dengan benar
            $id_kelas = $kelas_id['id_kelas'];
            $this->db->where('id_kelas', $id_kelas);
            $query = $this->db->get('tb_kelas');
            $data['kelas'] = $query->result();

            $data['user'] = $this->db->get_where('tb_user', ['id_user' => $this->session->userdata('id_user')])->row_array();

            $id_kelas = $kelas_id['id_kelas'];
            $this->db->where('id_kelas', $id_kelas);
            $this->db->order_by('tgl_buat', 'DESC'); // Menambahkan pengurutan berdasarkan kolom waktu_tugas secara descending
            $query = $this->db->get('tb_tugas');
            $data['tugas'] = $query->result();


            $data['title'] = 'StarAcademy | Video Belajar';
            $this->load->view('guru/header_kelas', $data);
            $this->load->view('guru/vidbel', $data);
        } else {
            // Tindakan jika tidak ada sesi yang dipilih
            $data['kelas'] = array();
            $data['title'] = 'StarAcademy | Kelas Tidak Ditemukan';

            $this->load->view('guru/header_beranda', $data);
            $this->load->view('guru/beranda', $data);
        }
    }


    public function BuatVidbel($id_kelas = null)
    {
        if ($id_kelas !== null) {
            // Pastikan id_kelas yang diset di sesi sesuai dengan yang diharapkan
            $sesi_data = array('id_kelas' => $id_kelas);
            $this->session->set_userdata('kelas', $sesi_data);
        }

        $kelas_id = $this->session->userdata('kelas');

        if ($kelas_id && isset($kelas_id['id_kelas'])) {
            $id_kelas = $kelas_id['id_kelas'];
            $data['kelas'] = $this->db->get_where('tb_kelas', array('id_kelas' => $id_kelas))->row(); // Use row() instead of result()

            $data['user'] = $this->db->get_where('tb_user', array('id_user' => $this->session->userdata('id_user')))->row_array();

            $this->form_validation->set_rules('judul_vidbel', 'Judul Video Belajar', 'required|trim');
            $this->form_validation->set_rules('lampiran', 'Lampiran', 'required|trim');

            if ($this->form_validation->run() == false) {
                $data['title'] = 'StarAcademy | Buat Video Belajar';
                $this->load->view('guru/buat_vidbel', $data);
            } else {
                // Handle file upload
                $config['upload_path']   = './uploads/';
                $config['allowed_types'] = 'mp4|avi|mov'; // Specify allowed video file types
                $config['max_size']      = 10240; // Maximum file size in kilobytes (10 MB)

                $this->load->library('upload', $config);

                if (!$this->upload->do_upload('lampiran')) {
                    // If file upload fails, show the form again with upload errors
                    $upload_error = $this->upload->display_errors();
                    var_dump($upload_error); // Display the error message for debugging
                    $data['upload_error'] = $upload_error;
                    $this->load->view('your_view_name', $data);
                } else {
                    // If file upload is successful, insert data into the database
                    $upload_data = $this->upload->data();

                    $judul_vidbel = $this->input->post('judul_vidbel', true);
                    $tanggal = date('Y-m-d H:i:s');
                    $lampiran = $upload_data['file_name']; // Use $upload_data to get the file name

                    $id_vidbel_unique = false;
                    while (!$id_vidbel_unique) {
                        $id_vidbel = substr(uniqid(), -10);
                        $query = $this->db->get_where('tb_vidbel', array('id_vidbel' => $id_vidbel));
                        if ($query->num_rows() == 0) {
                            $id_vidbel_unique = true;
                        }
                    }

                    $data = array(
                        'id_vidbel' => $id_vidbel,
                        'id_kelas' => $id_kelas,
                        'judul_vidbel' => htmlspecialchars($judul_vidbel),
                        'lampiran' => $lampiran,
                        'tanggal' => $tanggal,
                    );

                    // Move the database insertion inside the else block
                    $this->db->insert('tb_vidbel', $data);

                    $this->session->set_flashdata('notif', '<div class="alert alert-success" role="alert">Tugas Berhasil Dibuat!</div>');
                    redirect('guru/vidbel');
                }
            }
        }
    }

    public function anggota($id_kelas = null)
    {
        // Set sesi hanya jika id_kelas ada dan bukan null
        if ($id_kelas !== null) {
            // Pastikan id_kelas yang diset di sesi sesuai dengan yang diharapkan
            $sesi_data = array('id_kelas' => $id_kelas);
            $this->session->set_userdata('kelas', $sesi_data);
        }

        // Ambil data sesuai dengan session 'kelas'
        $kelas_id = $this->session->userdata('kelas');

        if ($kelas_id && isset($kelas_id['id_kelas'])) {
            // Pastikan nilai 'id_kelas' yang diambil dari sesi digunakan dengan benar
            $id_kelas = $kelas_id['id_kelas'];
            $this->db->where('id_kelas', $id_kelas);
            $query = $this->db->get('tb_kelas');
            $data['kelas'] = $query->result();

            $data['user'] = $this->db->get_where('tb_user', ['id_user' => $this->session->userdata('id_user')])->row_array();

            $id_kelas = $kelas_id['id_kelas'];
            $this->db->where('id_kelas', $id_kelas);
            $query = $this->db->get('tb_anggota');
            $data['anggota'] = $query->result();

            $data['title'] = 'StarAcademy | Kelas';
            $this->load->view('guru/header_kelas', $data);
            $this->load->view('guru/anggota', $data);
        } else {
            // Tindakan jika tidak ada sesi yang dipilih
            $data['kelas'] = array();
            $data['title'] = 'StarAcademy | Kelas Tidak Ditemukan';

            $this->load->view('guru/header_beranda', $data);
            $this->load->view('guru/beranda', $data);
        }
    }

    public function delete_anggota($id_user)
    {
        $this->db->where('id_user', $id_user);
        $this->db->delete('tb_anggota');

        $this->session->set_flashdata('notif', '<div class="alert alert-success w-25 mt-2" role="alert">Data Berhasil Dihapus !</div>');
        redirect($_SERVER['HTTP_REFERER']);
    }

    public function delete_tugas($id_tugas)
    {
        $this->db->where('id_tugas', $id_tugas);
        $this->db->delete('tb_tugas');

        $this->session->set_flashdata('notif', '<div class="alert alert-success w-25 mt-2" role="alert">Data Berhasil Dihapus !</div>');
        redirect($_SERVER['HTTP_REFERER']);
    }
}

/* End of file Siswa.php and path \application\controllers\Siswa.php */
