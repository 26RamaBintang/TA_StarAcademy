<?php
defined('BASEPATH') or exit('No direct script access allowed');

class siswa extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        is_logged_in();
    }

    public function index()
    {
        $user_id = $this->session->userdata('id_user');
        // Mengambil data user
        $data['user'] = $this->db->get_where('tb_user', ['id_user' => $user_id])->row_array();

        // Mengambil daftar kelas yang terkait dengan user
        $data['list'] = $this->db->get_where('tb_anggota', ['id_user' => $user_id])->result_array();

        $data['title'] = 'StarAcademy | Beranda';
        $this->load->view('siswa/header_beranda', $data);
        $this->load->view('siswa/beranda', $data);
    }


    public function edit()
    {
        $data['user'] = $this->db->get_where('tb_user', ['id_user' => $this->session->userdata('id_user')])->row_array();

        $data['title'] = 'StarAcademy | Beranda';

        $this->form_validation->set_rules('username', 'Username', 'required|trim');

        if ($this->form_validation->run() == false) {
            $this->load->view('siswa/header_beranda', $data);
            $this->load->view('siswa/beranda');
        } else {
            $username = $this->input->post('username');
            $id_user = $this->input->post('id_user');

            $this->db->set('username', $username);
            $this->db->where('id_user', $id_user);
            $this->db->update('tb_user');

            $this->session->set_flashdata('notif', '<div class="alert alert-success" role="alert">Profile Berhasil Diubah !</div>');
            redirect('siswa');
        }
    }

    public function GabungKelas()
    {
        $this->form_validation->set_rules('kode', 'Kode', 'required|trim|min_length[7]', [
            'min_length' => 'Kode kelas terdiri dari 7 karakter yang mencakup huruf dan angka, tanpa spasi atau simbol !'
        ]);
        $kelas = $this->db->get_where('tb_kelas', ['id_kelas' => $this->input->post('kode')])->row_array();

        if (!$kelas) {
            redirect('siswa');
        }

        // Jika id_kelas ditemukan, lanjutkan proses
        $user = $this->db->get_where('tb_user', ['id_user' => $this->session->userdata('id_user')])->row_array();

        $isUserAlreadyInClass = $this->db->get_where('tb_anggota', [
            'id_kelas' => $kelas['id_kelas'],
            'id_user' => $user['id_user']
        ])->row_array();

        if ($isUserAlreadyInClass) {
            // Jika pengguna sudah tergabung dalam kelas tersebut, tidak perlu melakukan apa pun
            redirect('siswa');
        } else if ($this->form_validation->run() == false) {
            $data['title'] = 'StarAcademy | Beranda';
            $this->load->view('siswa/header_beranda', $data);
            $this->load->view('siswa/beranda', $data);
        } else {
            $data = array(
                'id_kelas' => $kelas['id_kelas'],
                'id_user' => $user['id_user'],
                'username' => $user['username'],
                'nama_kelas' => $kelas['nama_kelas'],
                'mata_pelajaran' => $kelas['mata_pelajaran'],
            );

            // Lakukan penyisipan data karena pengguna belum tergabung dalam kelas tersebut
            $this->db->insert('tb_anggota', $data);
            $this->index();
        }
    }

    public function kelas($id_kelas = null)
    {
        // Set sesi hanya jika id_kelas ada dan bukan null
        if ($id_kelas !== null) {
            // Pastikan id_kelas yang diset di sesi sesuai dengan yang diharapkan
            $sesi_data = array('id_kelas' => $id_kelas);
            $this->session->set_userdata('kelas', $sesi_data);
        }

        // Ambil data sesuai dengan session 'kelas'
        $kelas_id = $this->session->userdata('kelas');

        if ($kelas_id && isset($kelas_id['id_kelas'])) {
            // Pastikan nilai 'id_kelas' yang diambil dari sesi digunakan dengan benar
            $id_kelas = $kelas_id['id_kelas'];
            $this->db->where('id_kelas', $id_kelas);
            $query = $this->db->get('tb_kelas');
            $data['kelas'] = $query->result();

            $data['user'] = $this->db->get_where('tb_user', ['id_user' => $this->session->userdata('id_user')])->row_array();

            $id_kelas = $kelas_id['id_kelas'];
            $this->db->where('id_kelas', $id_kelas);
            $this->db->order_by('tgl_buat', 'DESC'); // Menambahkan pengurutan berdasarkan kolom waktu_tugas secara descending
            $query = $this->db->get('tb_tugas');
            $data['tugas'] = $query->result();


            $data['title'] = 'StarAcademy | Kelas';
            $this->load->view('siswa/header_kelas', $data);
            $this->load->view('siswa/kelas', $data);
        } else {
            // Tindakan jika tidak ada sesi yang dipilih
            $data['kelas'] = array();
            $data['title'] = 'StarAcademy | Kelas Tidak Ditemukan';

            $this->load->view('siswa/header_beranda', $data);
            $this->load->view('siswa/beranda', $data);
        }
    }

    public function tampil_tugas($id_tugas = null, $id_kelas = null)
    {
        // Set sesi hanya jika id_tugas ada dan bukan null
        if ($id_tugas !== null) {
            $sesi_data = array('id_tugas' => $id_tugas);
            $this->session->set_userdata('id_tugas', $sesi_data);
        }

        // Set sesi hanya jika id_kelas ada dan bukan null
        if ($id_kelas !== null) {
            $sesi_data_kelas = array('id_kelas' => $id_kelas);
            $this->session->set_userdata('kelas', $sesi_data_kelas);
        }

        // Ambil data sesuai dengan session 'kelas'
        $kelas_id = $this->session->userdata('kelas');

        if ($kelas_id && isset($kelas_id['id_kelas'])) {
            // Ambil ID kelas dari sesi
            $id_kelas = $kelas_id['id_kelas'];
            $id_tugas = $this->session->userdata('id_tugas')['id_tugas'];

            $data['user'] = $this->db->get_where('tb_user', ['id_user' => $this->session->userdata('id_user')])->row_array();
            $data['kelas'] = $this->db->get_where('tb_kelas', ['id_kelas' => $id_kelas])->row_array();
            $data['tugas'] = $this->db->get_where('tb_tugas', ['id_tugas' => $id_tugas])->row_array();



            $data['title'] = 'StarAcademy | Tugas';
            $this->load->view('siswa/header_kelas', $data);
            // var_dump($data);
            $this->load->view('siswa/tampil_tugas', $data);
        }
    }

    public function komen($id_kelas = null)
    {
        if ($id_kelas !== null) {
            // Pastikan id_kelas yang diset di sesi sesuai dengan yang diharapkan
            $sesi_data = array('id_kelas' => $id_kelas);
            $this->session->set_userdata('kelas', $sesi_data);
        }

        $kelas_id = $this->session->userdata('kelas');

        if ($kelas_id && isset($kelas_id['id_kelas'])) {
            // Pastikan nilai 'id_kelas' yang diambil dari sesi digunakan dengan benar
            $id_kelas = $kelas_id['id_kelas'];
            $this->db->where('id_kelas', $id_kelas);
            $query = $this->db->get('tb_kelas');
            $data['kelas'] = $query->result();

            $id_kelas = $kelas_id['id_kelas'];
            $this->db->where('id_kelas', $id_kelas);
            $this->db->order_by('tanggal', 'DESC');
            $query = $this->db->get('tb_komen');
            $data['komen'] = $query->result();

            $data['user'] = $this->db->get_where('tb_user', ['id_user' => $this->session->userdata('id_user')])->row_array();

            $data['title'] = 'StarAcademy | Kelas';

            $this->form_validation->set_rules('komen', 'Komen', 'required|trim');
            if ($this->form_validation->run() == false) {
                $data['title'] = 'StarAcademy | Komen';
                $this->load->view('siswa/header_kelas', $data);
                $this->load->view('siswa/komen', $data);
            } else {
                $kelas_id = $this->session->userdata('kelas');

                if ($kelas_id && isset($kelas_id['id_kelas'])) {
                    $id_kelas = $kelas_id['id_kelas'];

                    // Mengambil data dari formulir
                    $komen = $this->input->post('komen', true);
                    $pengirim = $this->input->post('pengirim', true);
                    $username = $this->input->post('nama_pengirim', true);
                    $tanggal = date('Y-m-d H:i:s');

                    // Menghasilkan id_tugas yang unik
                    $id_tugas_unique = false;
                    while (!$id_tugas_unique) {
                        $id_tugas = substr(uniqid(), -10);
                        $query = $this->db->get_where('tb_tugas', array('id_tugas' => $id_tugas));
                        if ($query->num_rows() == 0) {
                            $id_tugas_unique = true;
                        }
                    }

                    // Menyiapkan data untuk di-insert ke database
                    $insert_data = array(
                        'id_kelas' => $id_kelas,
                        'id_user' => $pengirim,
                        'username' => $username,
                        'komen' => htmlspecialchars($komen),
                        'tanggal' => $tanggal,
                    );

                    // Memanggil model untuk melakukan insert ke database
                    $this->db->insert('tb_komen', $insert_data);

                    // Menampilkan notifikasi dan mengarahkan kembali ke halaman kelas
                    redirect('siswa/komen');
                }
            }
        } else {
            // Tindakan jika tidak ada sesi yang dipilih
            $data['kelas'] = array();
            $data['title'] = 'StarAcademy | Kelas Tidak Ditemukan';

            $this->load->view('siswa/header_beranda', $data);
            $this->load->view('siswa/beranda', $data);
        }
    }

    public function anggota($id_kelas = null)
    {
        // Set sesi hanya jika id_kelas ada dan bukan null
        if ($id_kelas !== null) {
            // Pastikan id_kelas yang diset di sesi sesuai dengan yang diharapkan
            $sesi_data = array('id_kelas' => $id_kelas);
            $this->session->set_userdata('kelas', $sesi_data);
        }

        // Ambil data sesuai dengan session 'kelas'
        $kelas_id = $this->session->userdata('kelas');

        if ($kelas_id && isset($kelas_id['id_kelas'])) {
            // Pastikan nilai 'id_kelas' yang diambil dari sesi digunakan dengan benar
            $id_kelas = $kelas_id['id_kelas'];
            $this->db->where('id_kelas', $id_kelas);
            $query = $this->db->get('tb_kelas');
            $data['kelas'] = $query->result();

            $data['user'] = $this->db->get_where('tb_user', ['id_user' => $this->session->userdata('id_user')])->row_array();

            $id_kelas = $kelas_id['id_kelas'];
            $this->db->where('id_kelas', $id_kelas);
            $query = $this->db->get('tb_anggota');
            $data['anggota'] = $query->result();

            $data['title'] = 'StarAcademy | Kelas';
            $this->load->view('siswa/header_kelas', $data);
            $this->load->view('siswa/anggota', $data);
        }
    }
}

/* End of file Siswa.php and path \application\controllers\Siswa.php */
