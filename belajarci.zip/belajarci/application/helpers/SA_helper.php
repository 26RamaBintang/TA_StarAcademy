<?php 

function is_logged_in()
{
    $ci = get_instance();
    if (!$ci->session->userdata('username')) {
        redirect('auth');
    } else {
        $status = $ci->session->userdata('status');
        $menu = $ci->uri->segment(1);

        $queryMenu = $ci->db->get_where('tb_user', ['status' => $menu])->row_array();
        $menu_id = $queryMenu['status'];

        if ( $status != $menu_id) {
            redirect('auth/blocked');
        }
    }
}