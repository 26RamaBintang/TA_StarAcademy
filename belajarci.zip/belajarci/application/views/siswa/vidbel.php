<?php $this->load->view('layout'); ?>

<!-- start menu -->
<nav class="core-core font navbar-expand-lg bg-body-tertiary">
    <div class="container-fluid">
        <div class="row flex-wrap">
            <div class="col" style="background-color: #FFF; margin-left: 190px;"><br>
                <div class="row flex-wrap">
                    <nav class="nav mt-5 navbar-expand-lg bg-body-tertiary nav-nav-menu" style="position: fixed; border-bottom: solid 1px #666; background-color: #FFF; z-index: 1;">
                        <li class="nav-item mx-2 ">
                            <a class="nav-link" href="kelas" style="color: #666;">Kelas</a>
                        </li>
                        <li class="nav-item mx-2">
                            <a class="nav-link" href="komen" style="color: #666;">Komen</a>
                        </li>
                        <li class="nav-item mx-2" style="border-bottom: solid 3px #217756;">
                            <a class="nav-link" href="vidbel" style="color: #217756;">Video Belajar</a>
                        </li>
                        <li class="nav-item mx-2">
                            <a class="nav-link" href="anggota" style="color: #666;">Anggota</a>
                        </li>
                        <li class="nav-item mx-2">
                            <a class="nav-link" href="peringkat" style="color: #666;">Peringkat</a>
                        </li>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</nav>

<div class="core-core row row-cols-2 mt-5 pt-5 nav-nav-judul font" style="background-color: #FFF; margin-left: 190px;">

    <!-- start vidbel -->
    


    <!-- vidbel end -->
</div>

</body>

</html>