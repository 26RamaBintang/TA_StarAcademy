<?php $this->load->view('layout_tugas'); ?>

<div class="container-fluid mt-5 pt-5 font">
    <div class="row">
        <div class="col-1">
            <a href="kelas" class="fa-solid fa-chevron-left fs-4 ms-3 mt-2" style="color: #666; text-decoration:none;"></a>
        </div>

        <div class="col ms-5">
            <div class="col pb-3 border-bottom border-3" style="color: #666;">
                <img src="../../assets/image/task.png" style="width: 45px; height: fit-content;">
                <a class="ms-4 fs-4 text-black" style="text-decoration:none;">Penjumlahan Matriks</a>
            </div>
            <div class="container-fluid py-3 border-bottom border-3 ">Petunjuk
            </div>
            <div class="container-fluid py-3">
                <label>Lampiran</label>
                <!-- <embed type="assets/file/" src="LATIHAN SOAL FUNGSI KOMPOSISI DAN INVERS.docx"> -->
            </div>
        </div>
        <div class="col-4 pe-5">
            <div class="container">
                <div class="card shadow">
                    <div class="card-body">
                        <div class="row card-title">
                            <div class="col"><strong>Ditugaskan</strong></div>
                            <div class="col text-end" style="color: #666;">/ 100</div>
                        </div>
                        <div class="row mx-1 my-3">
                            <img id="output" width="200" />
                        </div>
                        <div class="row mx-3">
                            <input class=" form-control btn my-2 border-2 border-success text-success" type="file" id="file-upload" onchange="loadFile(event)" hidden multiple>
                            <label class="btn border border-2 border-success text-success" for="file-upload">+ Upload File</label>

                            <script>
                                var loadFile = function(event) {
                                    var file = document.getElementById('output');
                                    file.src = URL.createObjectURL(event.target.files[0]);
                                };
                            </script>

                            <input type="submit" class="btn btn-success my-2" value="KIRIM">
                        </div>
                    </div>

                </div>

            </div>
        </div>
    </div>
</div>



</body>

</html>