<!-- start menu -->
<nav class="core-core font navbar-expand-lg bg-body-tertiary">
    <div class="container-fluid">
        <div class="row flex-wrap">
            <div class="col" style="background-color: #FFF; margin-left: 190px;"><br>
                <div class="row flex-wrap">
                    <nav class="nav mt-5 navbar-expand-lg nav-nav-menu" style="position: fixed; border-bottom: solid 1px #666; background-color: #FFF; z-index: 1;">
                        <?php foreach ($kelas as $item) : ?>
                            <li class="nav-item mx-2 " style="border-bottom: solid 3px #217756;">
                                <a class="nav-link" href="<?= base_url('siswa/kelas/' . $item->id_kelas) ?>" style="color: #217756;">Tugas</a>
                            </li>
                            <li class="nav-item mx-2">
                                <a class="nav-link" href="<?= base_url('siswa/komen/' . $item->id_kelas) ?>" style="color: #666;">Komen</a>
                            </li>
                            <li class="nav-item mx-2">
                                <a class="nav-link" href="vidbel" style="color: #666;">Video Belajar</a>
                            </li>
                            <li class="nav-item mx-2">
                                <a class="nav-link" href="<?= base_url('siswa/anggota/' . $item->id_kelas) ?>" style="color: #666;">Anggota</a>
                            </li>
                        <?php endforeach; ?>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</nav>
<!-- end menu -->
<div class="core-core row row-cols-2 mt-5 nav-nav-judul font" style=" background-image: url('bg-kelas.png'); margin-left: 190px;">
    <div class="col mx-auto mt-5" style="text-decoration: none; width: 90%;">
        <!-- views/guru/kelas.php -->

        <?php if (!empty($kelas)) : ?>
            <?php foreach ($kelas as $item) : ?>
                <div class="card kelas mt-4 shadow">
                    <div class="card-body">
                        <h3 class="card-title"><?= $item->nama_kelas ?></h3>
                        <h5 class="card-text mb-5"><?= $item->mata_pelajaran ?></h5>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
    <!-- start tugas -->

    <div class="container-fluid border rounded-1 border-black my-4 px-4 py-2 shadow w-75" style=" text-decoration: none; ">
        <?php foreach ($tugas as $tampil) : ?>
            <div class="container-fluid border my-3 border-black rounded-1">
                <div class="row">
                    <div class="col">
                        <a href="<?=  base_url('siswa/tampil_tugas/' . $tampil->id_tugas . '/' . $item->id_kelas) ?>" class="font row p-2" style="color: #000; text-decoration: none;">
                            <div class="col-md-auto d-flex align-items-center ">
                                <img src="<?= base_url('assets/image/task.png')?>" style="width: 40px; height: fit-content;">
                            </div>
                            <div class="col">
                                <div class="col" style="font-size: large;">
                                    <?= $tampil->judul_tugas ?>
                                </div>
                                <div style="font-size: small;">
                                    <?= date('Y-m-d H:i', strtotime($tampil->tgl_buat)) ?>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>


        <!-- tugas end -->
    </div>

</div>

</body>

</html>