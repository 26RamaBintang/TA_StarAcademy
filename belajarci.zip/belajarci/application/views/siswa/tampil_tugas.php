<!-- start menu -->
<nav class="core-core font navbar-expand-lg bg-body-light">
    <div class="container-fluid">
        <div class="row flex-wrap">
        </div>
    </div>
</nav>

<!-- Content Section -->
<div class="core-core row row-cols-2 mt-3 pt-5 nav-nav-judul font" style="background-color: #FFF; margin-left: 100px;">

    <!-- Start Tugas -->
    <div class="container-fluid my-4 py-2" style="text-decoration: none; width: 80%;">

        <div class="row">
            <div class="col-1 mt-2">
                <a href="javascript:history.go(-1)">
                    <i class="fa-solid fa-chevron-left fa-fw fs-4" style="color: black;"></i>
                </a>
            </div>
            <div class="col">
                <div class="row d-flex align-items-center fs-5">
                    <div class="col-1" style="margin-left: 10px;">
                        <img src="<?= base_url('assets/image/task.png') ?>" style="width: 45px; height: fit-content;">

                    </div>
                    <div class="col fs-3">
                        <?= $tugas['judul_tugas']; ?>
                    </div>
                </div>
                <div class="d-flex align-items-end fs-5">
                    Tenggat : <?= date('M d,  H.i', strtotime($tugas['tenggat'])); ?>
                </div>
                <hr>

                <div>
                    <?= $tugas['petunjuk']; ?>
                </div>
                <hr>

                <?php if (!empty($tugas['lampiran'])) : ?>
                    <div>
                        <h5>Lampiran</h5>
                        <div class="card mb-3" style="max-width: 400px;">
                            <div class="row g-0">
                                <div class="col-md-4">
                                    <img src="<?= base_url('assets/image/lampiran/') . $tugas['lampiran']; ?>" class="img-fluid rounded-start" alt="..." data-bs-toggle="modal" data-bs-target="#lampiranModal">
                                </div>
                                <div class="col-md-8">
                                    <div class="card-body">
                                        <h5 class="card-title"><?= $tugas['lampiran']; ?></h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Modal -->
                    <div class="modal fade" id="lampiranModal" tabindex="-1" role="dialog" aria-labelledby="lampiranModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="lampiranModalLabel"><?= $tugas['lampiran']; ?></h5>
                                    <button type="button" class="btn fs-3" data-bs-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body text-center">
                                    <img src="<?= base_url('assets/image/lampiran/') . $tugas['lampiran']; ?>" class="img-fluid" alt="...">
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            <div class="col-4">
                <div class="card border-2 border-success ms-3">
                    <div class="row m-2">
                        <div class="col">
                            Ditugaskan
                        </div>
                        <div class="col-4 d-flex align-items-end">
                            0 / 100
                        </div>

                    </div>
                    <div class="row ">
                        <form action="" style="overflow-y: auto; height: auto; position: relative;">
                            <div style="position: sticky; bottom:0;">
                                <label class="btn btn-success w-75 rounded fs-6 form-group form-floating ms-5 my-2">
                                    <input type="file" class="form-control" id="jawaban" name="jawaban" style="display: none;">
                                    <i class="fa-solid fa-plus me-2"></i>
                                    Upload Jawaban
                                </label>
                                <label class="btn btn-outline-success border-2 w-75 rounded fs-6 form-group form-floating ms-5 my-2">
                                    <input type="file" class="form-control" id="kirim" name="kirim" style="display: none;">
                                    Kirim
                                </label>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Tugas -->

</div>



</body>

</html>