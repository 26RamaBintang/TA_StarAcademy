<!-- Content Section -->
<div class="core-core row row-cols-2 pt-5 nav-nav-judul font" style="background-color: #FFF; margin-left: 100px;">

    <!-- Start Tugas -->
    <div class="container-fluid my-4 px-4 py-2" style="text-decoration: none; width: 80%;">
        <div class="row">
            <div class="col-1 mt-2">
                <a href="<?= base_url('guru/kelas/' . $tugas['id_kelas']) ?>">
                    <i class="fa-solid fa-chevron-left fa-fw fs-4" style="color: black;"></i>
                </a>
            </div>
            <div class="col">
                <div class="row d-flex align-items-center fs-5">
                    <div class="col-1" style="margin-left: 10px;">
                        <img src="<?= base_url('assets/image/task.png') ?>" style="width: 45px; height: fit-content;">

                    </div>
                    <div class="col fs-3">
                        <?= $tugas['judul_tugas']; ?>
                    </div>
                    <div class="col-1 d-flex align-items-center justify-content-end me-2">
                        <span class="dropdown">
                            <button class="btn" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fa-solid fa-ellipsis-vertical fs-5"></i>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <div>
                                    <li><a type="button" class="dropdown-item" href="<?= base_url('guru/edit_tugas/') . $tugas['id_tugas']; ?>">Edit</a></button></li>
                                </div>
                            </ul>
                        </span>
                    </div>
                </div>
                <div class="row d-flex align-items-end fs-5">
                    Tenggat : <?= date('M d,  H.i', strtotime($tugas['tenggat'])); ?>
                </div>
                <hr>

                <div>
                    <?= $tugas['petunjuk']; ?>
                </div>
                <hr>

                <?php if (!empty($tugas['lampiran'])) : ?>
                    <div>
                        <h5>Lampiran</h5>
                        <?php foreach ($tugas['lampiran'] as $item) : ?>
                            <?php if ($item['type'] != 'image') : ?>
                                <!-- Jika file dokumen -->
                                <div class="card mb-3" style="max-width: 400px;">
                                    <div class="row g-0">
                                        <a href="<?= base_url('assets/image/lampiran/') . $item['nama']; ?>" target="_blank">
                                            <div class="col-md-4">
                                                <a href="<?= base_url('assets/image/lampiran/') . $item['nama']; ?>" target="_blank">
                                                    <img src="<?= $item['icon']; ?>" class="img-fluid rounded-start" alt="...">
                                                </a>
                                            </div>
                                            <div class="col-md-8">
                                                <div class="card-body">
                                                    <h5 class="card-title"><?= $item['nama']; ?></h5>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            <?php else : ?>
                                <!-- Jika file gambar -->
                                <div class="card mb-3" style="max-width: 400px;">
                                    <a href="<?= base_url('assets/image/lampiran/') . $item['nama']; ?>" target="_blank">
                                        <div class="row g-0">
                                            <div class="col-md-4">
                                                <a href="<?= base_url('assets/image/lampiran/') . $item['nama']; ?>" target="_blank">
                                                    <img src="<?= base_url('assets/image/lampiran/') . $item['nama']; ?>" class="img-fluid rounded-start" alt="...">
                                                </a>
                                            </div>
                                            <div class="col-md-8">
                                                <div class="card-body">
                                                    <h5 class="card-title"><?= $item['nama']; ?></h5>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            <?php endif; ?>

                            <!-- Modal -->
                            <div class="modal fade" id="lampiranModal<?= md5($item['nama']); ?>" tabindex="-1" role="dialog" aria-labelledby="lampiranModalLabel<?= md5($item['nama']); ?>" aria-hidden="true">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="lampiranModalLabel<?= md5($item['nama']); ?>"><?= $item['nama']; ?></h5>
                                            <button type="button" class="btn fs-3" data-bs-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body text-center">
                                            <img src="<?= base_url('assets/image/lampiran/') . $item['nama']; ?>" alt="...">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>


            </div>
        </div>
        <!-- End Tugas -->

    </div>
</div>