<!-- start sidebar -->

<nav class="sidebar navbar-expand-lg bg-body-tertiary">
    <div class="container-fluid">
        <div class="row flex-wrap">
            <div class="col-auto ps-0 position-fixed" style=" overflow-x:hidden; border-right:solid 1px; background-color: #FFF;">
                <div class="d-flex flex-column align-items-sm-center text-white min-vh-100"><br><br>
                    <ul class="nav nav-pills flex-column align-items-sm-start" id="menu">
                        <li class="nav-item">
                            <a href="beranda" class="sidebar-menu-aktif p-2 px-sm-4 px-4 " style="color:#fff; font-size:20px;">
                                <i class="fa-solid fa-house"></i>
                                <span class="ms-3 d-none d-sm-inline">Beranda</span>
                            </a>
                        </li>
                        <hr>
                        <li class=" nav-item dropdown">
                            <a href="#" class="menu-aktif p-2 px-sm-4 px-4 dropdown-toggle" style="color:#217756; font-size:20px;">
                                <i class="fa-solid fa-chalkboard-user"></i>
                                <span class="ms-3 d-none d-sm-inline">Kelas</span>
                                <i></i>
                            </a>
                        </li>
                        <li class="nav-item position-fixed bottom-0 pb-3">
                            <a href="<?= base_url('auth/keluar'); ?>" class="menu-aktif p-2 px-sm-4 px-4 mb-2" style="color:#217756; font-size:20px;">
                                <i class="fa-solid fa-arrow-right-from-bracket" style="transform: scaleX(-1);"></i>
                                <span class="ms-3 d-none d-sm-inline">Keluar</span>
                            </a>


                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</nav>
<!-- sidebar end -->

<div class="row row-cols-4 mt-5 core-core" style="background-color: #FFF; margin-left: 190px;">
    <?php foreach ($list as $kelas) : ?>
        <a class="col ms-4 mt-5" href="<?= base_url('guru/kelas/' . $kelas['id_kelas']) ?>" style="text-decoration: none; width:300px;">
            <div class="card kelas" style="height: 150px;">
                <div class="card-body">
                    <h3 class="card-title"><?= $kelas['nama_kelas'] ?></h3>
                    <h5 class="card-text mb-3"><?= $kelas['mata_pelajaran'] ?></h5>
                </div>
            </div>
        </a>
    <?php endforeach; ?>

</div>




</body>

</html>