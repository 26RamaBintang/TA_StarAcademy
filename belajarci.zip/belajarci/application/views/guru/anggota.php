<!-- start menu -->
<nav class="core-core font navbar-expand-lg bg-body-light">
    <div class="container-fluid">
        <div class="row flex-wrap">
            <div class="col" style="background-color: #FFF; margin-left: 190px;"><br>
                <div class="row flex-wrap">
                    <nav class="nav mt-5 navbar-expand-lg bg-body-light nav-nav-menu" style="position: fixed; border-bottom: solid 1px #666; background-color: #FFF; z-index: 1;">
                        <?php foreach ($kelas as $item) : ?>
                            <li class="nav-item mx-2 ">
                                <a class="nav-link" href="<?= base_url('guru/kelas/' . $item->id_kelas) ?>" style="color: #666;">Tugas</a>
                            </li>
                            <li class="nav-item mx-2">
                                <a class="nav-link" href="<?= base_url('guru/komen/' . $item->id_kelas) ?>" style="color: #666;">Komen</a>
                            </li>
                            <li class="nav-item mx-2">
                                <a class="nav-link" href="<?= base_url('guru/vidbel/' . $item->id_kelas) ?>" style="color: #666;">Video Belajar</a>
                            </li>
                            <li class="nav-item mx-2" style="border-bottom: solid 3px #217756;">
                                <a class="nav-link" href="<?= base_url('guru/anggota/' . $item->id_kelas) ?>" style="color: #217756;">Anggota</a>
                            </li>
                        <?php endforeach; ?>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</nav>

<div class="core-core row row-cols-2 mt-5 pt-5 nav-nav-judul font" style="background-color: #FFF; margin-left: 190px;">

    <!-- start tugas -->

    <div class="container-fluid my-4 px-4 py-2" style="text-decoration: none; width: 80%;">
        <?php foreach ($anggota as $item) : ?>
            <div class="font row p-2 border-bottom mb-1 border-1 border-black" style="color: #000; text-decoration: none;">
                <div class="col-1 d-flex align-items-center">
                    <i class="fa-solid fa-circle-user" style="font-size: 35px; color:#63B75D;"></i>
                </div>
                <div class="col d-flex align-items-center fs-5">
                    <?= $item->username ?>
                </div>
                <div class="col-1 d-flex align-items-center justify-content-end me-2">
                    <span class="dropdown">
                        <button class="btn" type="button" data-bs-toggle="modal" data-bs-target="#keluarkan<?= $item->id_user ?>">
                            <i class="fa-solid fa-ellipsis-vertical fs-5"></i>
                        </button>
                    </span>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <!-- tugas end -->
</div>

<?php foreach ($anggota as $item) : ?>
    <div class="modal fade" id="keluarkan<?= $item->id_user ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content p-3">
                <div class="modal-body fs-5">Apakah Anda Ingin Menghapus "<?= $item->username ?>" ?</div>
                <div class="row d-flex justify-content-end m-3">
                    <div class="col-2">
                        <button class="btn" type="button" data-bs-dismiss="modal">Batal</button>
                    </div>
                    <div class="col-2">
                        <a class="btn text-danger" href="<?= base_url('guru/delete_anggota/') . $item->id_user ?>"><b>Hapus</b></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>

</body>

</html>