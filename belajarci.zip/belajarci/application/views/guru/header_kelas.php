<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<html>

<head>
    <link rel="shortcut icon" href="<?php echo base_url('assets\image\mini-logo.png') ?>">
    <title><?= $title; ?></title>
    <link href="<?php echo base_url('https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js') ?>" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous">
    <link href="<?php echo base_url('https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js') ?>" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous">
    <link href="<?php echo base_url('assets\css\bootstrap.min.css') ?>" rel="stylesheet">
    <link href="<?php echo base_url('assets\js\bootstrap.bundle.min.js') ?>" rel="stylesheet">
    <link href="<?= base_url('assets\css\tambahan.css?v=' . time()) ?>" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>

</head>

<body>
    <!-- start navbar -->

    <nav class="navbar fixed-top navbar-expand-lg shadow-sm" style="height: 72px; background-color: #FFF;">
        <div class="container-fluid">
            <a class="navbar-brand" href="beranda">&nbsp;&nbsp;&nbsp;&nbsp;
                <img src="<?= base_url("assets\image\LOGO.png") ?>" alt="StarAcademy" height="35" style="">
            </a>
            <div>

                <span class="dropdown">
                    <button class="btn" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fa-regular fa-circle-user fa-fw fs-1" style="color:#217756"></i>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <div>
                            <h4 class="text-center">Halo, <?= $user['username']; ?></h4>
                        </div>
                        <div>
                            <li><a type="button" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#exampleModal1">Edit Profile</a></button></li>
                            <li><a type="button" class="dropdown-item btn btn-danger" style="color: red;" href="<?= base_url('auth/keluar') ?>">Keluar</a></li>
                        </div>
                    </ul>
                </span>
            </div>
            <!-- Button trigger modal -->
        </div>
    </nav>


    <!-- Modal Edit Profile -->
    <div class="modal fade" id="exampleModal1" tabindex="-1" aria-labelledby="exampleModalLabel1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="d-flex justify-content-end">
                    <button type="button" class=" btn-close mt-3 me-3" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <h3 class="text-center">Edit Profile</h3>
                    <?= form_open_multipart('guru/edit'); ?>
                    <div class="mb-3">
                        <label for="recipient-name" class="col-form-label">ID Guru</label>
                        <input type="text" class="form-control" id="id_user" name="id_user" value="<?= $user['id_user']; ?>" readonly>
                    </div>
                    <div class="mb-3">
                        <label for="recipient-name" class="col-form-label">Username</label>
                        <input type="text" class="form-control" id="username" name="username" value="<?= $user['username']; ?>">
                        <?= form_error('username', '<small class="text-danger ms-2">', '</small>'); ?>
                    </div>
                    <div class="mb-3 text-end">
                        <button type="submit" class="btn btn-success">Simpan Perubahan</button>
                    </div>

                    </form>

                </div>
            </div>
        </div>
    </div>


    </div>

    <script>
        btnJoin = document.querySelectorAll('.btn-join');

        btnJoin.forEach(element => {
            element.onclick = () => {
                document.getElementById('kode').value = ''
            }
        });
        window.onload = () => {
            document.getElementById('kode').value = ''
        }
    </script>


    <!-- end navbar -->

    <!-- start sidebar -->

    <nav class="sidebar navbar-expand-lg bg-body-tertiary">
        <div class="container-fluid">
            <div class="row flex-wrap">
                <div class="col-auto ps-0 position-fixed" style=" overflow-x:hidden; border-right:solid 1px; background-color: #FFF;">
                    <div class="d-flex flex-column align-items-sm-center text-white min-vh-100"><br><br>
                        <ul class="nav nav-pills flex-column align-items-sm-start" id="menu">
                            <li class="nav-item mt-5">
                                <a href="<?= base_url('guru') ?>" class="menu-aktif p-2 px-sm-4 px-4 " style="color:#217756; font-size:20px;">
                                    <i class="fa-solid fa-house"></i>
                                    <span class="ms-3 d-none d-sm-inline">Beranda</span>
                                </a>
                            </li>
                            <hr>
                            <li class=" nav-item dropdown">
                                <a href="#" class="menu-aktif p-2 px-sm-4 px-4 dropdown-toggle" style="color:#217756; font-size:20px;">
                                    <i class="fa-solid fa-chalkboard-user"></i>
                                    <span class="ms-3 d-none d-sm-inline">Kelas</span>
                                    <i></i>
                                </a>
                            </li>
                            <li class="nav-item position-fixed bottom-0 pb-3">
                                <a href="<?= base_url('auth'); ?>" class="menu-aktif p-2 px-sm-4 px-4 mb-2" style="color:#217756; font-size:20px;">
                                    <i class="fa-solid fa-arrow-right-from-bracket" style="transform: scaleX(-1);"></i>
                                    <span class="ms-3 d-none d-sm-inline">Keluar</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </nav>
    <!-- sidebar end -->