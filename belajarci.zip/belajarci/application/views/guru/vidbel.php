<!-- start menu -->
<nav class="core-core font navbar-expand-lg bg-body-light">
    <div class="container-fluid">
        <div class="row flex-wrap">
            <div class="col" style="background-color: #FFF; margin-left: 190px;"><br>
                <div class="row flex-wrap">
                    <nav class="nav mt-5 navbar-expand-lg bg-body-light nav-nav-menu" style="position: fixed; border-bottom: solid 1px #666; background-color: #FFF; z-index: 1;">
                        <?php foreach ($kelas as $item) : ?>
                            <li class="nav-item mx-2 ">
                                <a class="nav-link" href="<?= base_url('guru/kelas/' . $item->id_kelas) ?>" style="color: #666;">Tugas</a>
                            </li>
                            <li class="nav-item mx-2">
                                <a class="nav-link" href="<?= base_url('guru/komen/' . $item->id_kelas) ?>" style="color: #666;">Komen</a>
                            </li>
                            <li class="nav-item mx-2" style="border-bottom: solid 3px #217756;">
                                <a class="nav-link" href="<?= base_url('guru/vidbel/' . $item->id_kelas) ?>" style="color: #217756;">Video Belajar</a>
                            </li>
                            <li class="nav-item mx-2">
                                <a class="nav-link" href="<?= base_url('guru/anggota/' . $item->id_kelas) ?>" style="color: #666;">Anggota</a>
                            </li>
                        <?php endforeach; ?>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</nav>

<div class="core-core row row-cols-2 mt-5 pt-5 nav-nav-judul font" style="background-color: #FFF; margin-left: 190px;">

    <!-- start vidbel -->
    <div class="container-fluid border rounded-1 border-black my-4 px-4 py-2 shadow w-75" style=" text-decoration: none; overflow-y: auto; height: 500px; position: relative;">
        <div class="d-flex justify-content-end mb-3" style=" position: relative; top: 400px;">
            <form action="<?= base_url('guru/BuatVidbel/' . $item->id_kelas) ?>" method="post">
                <!-- Menambahkan input hidden untuk menyimpan id_kelas -->
                <input type="hidden" name="id_kelas" value="<?= $this->session->userdata('id_kelas') ?>">

                <!-- Menggunakan button submit untuk membuka halaman BuatTugas -->
                <button type="submit" class="me-5 btn border rounded-circle fs-3" style="background: #63B75D;">
                    <i class="py-1 fa-solid fa-plus" style="color: #FFF;"></i>
                </button>
            </form>
        </div>
    </div>



    <!-- vidbel end -->
</div>

</body>

</html>