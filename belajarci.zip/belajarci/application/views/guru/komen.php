<!-- start menu -->
<nav class="core-core font navbar-expand-lg bg-body-light">
    <div class="container-fluid">
        <div class="row flex-wrap">
            <div class="col" style="background-color: #FFF; margin-left: 190px;"><br>
                <div class="row flex-wrap">
                    <nav class="nav mt-5 navbar-expand-lg bg-body-light nav-nav-menu" style="position: fixed; border-bottom: solid 1px #666; background-color: #FFF; z-index: 1;">
                        <?php foreach ($kelas as $item) : ?>
                            <li class="nav-item mx-2 ">
                                <a class="nav-link" href="<?= base_url('guru/kelas/' . $item->id_kelas) ?>" style="color: #666;">Tugas</a>
                            </li>
                            <li class="nav-item mx-2" style="border-bottom: solid 3px #217756;">
                                <a class="nav-link" href="<?= base_url('guru/komen/' . $item->id_kelas) ?>" style="color: #217756;">Komen</a>
                            </li>
                            <li class="nav-item mx-2">
                                <a class="nav-link" href="<?= base_url('guru/vidbel/' . $item->id_kelas) ?>" style="color: #666;">Video Belajar</a>
                            </li>
                            <li class="nav-item mx-2">
                                <a class="nav-link" href="<?= base_url('guru/anggota/' . $item->id_kelas) ?>" style="color: #666;">Anggota</a>
                            </li>
                        <?php endforeach; ?>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</nav>

<!-- ... (your previous HTML code) ... -->

<div class="core-core row row-cols-2 mt-5 pt-5 nav-nav-judul font" style="background-color: #FFF; margin-left: 190px; position: relative;">

    <!-- start komen -->
    <nav id="navbar-komen" class="container-fluid rounded-top border-black px-4 py-2 mx-auto mt-3" style="width: 80%; background-color:#217756; color:#FFF">
        KOMENTAR KELAS
    </nav>

    <div class="container-fluid border border-success border-top-0 border-3 rounded-bottom mb-5 px-4 py-3 mx-auto shadow" style="width: 80%; overflow-y: auto; height: 500px; position: relative;">
        <?php foreach ($komen as $komen) : ?>
            <div class="container">
                <div class="container row ps-2 border border-success rounded-end-3 rounded-bottom-3 border-3 p-2 ms-1 mb-3" style="width:fit-content">
                    <div class="row" style="color: black;">
                        <div class="col-3">
                            <b><?= $komen->username ?></b>
                        </div>
                        <div class="col">
                            <?= date('Y-m-d H:i', strtotime($komen->tanggal)) ?>
                        </div>
                    </div>
                    <div>
                        <?= $komen->komen ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>

        <div class="rounded-pill" style="padding: 10px; position: sticky; bottom:0; width: 100%; background-color:#fff">
            <?php foreach ($kelas as $item) : ?>
                <form action="<?= base_url('guru/komen/' . $item->id_kelas) ?>" method="post">
                    <div class="row">
                        <input type="hidden" name="pengirim" value="<?= $this->session->userdata('id_user') ?>">
                        <input type="hidden" name="nama_pengirim" value="<?= $this->session->userdata('username') ?>">
                        <div class="col">
                            <input class="form-control rounded-pill border-success" style="background-color: #cccccc;" type="text" name="komen" placeholder="Komen">
                        </div>
                        <div class="col-1">
                            <button class="btn btn-success p-2 rounded-circle" type="submit" name="submit">
                                <i class="fa-regular fa-paper-plane fs-5"></i>
                            </button>
                        </div>
                    </div>
                </form>
            <?php endforeach; ?>
        </div>

    </div>

</div>

<!-- ... (your remaining HTML code) ... -->




</body>

</html>