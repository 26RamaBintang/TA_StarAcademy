<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<html>

<head>
    <link rel="shortcut icon" href="<?= base_url('assets/image/mini-logo.png') ?>">
    <title><?= $title; ?></title>
    <link href="<?= base_url('assets/css/bootstrap.min.css') ?>" rel="stylesheet">
    <link href="<?= base_url('assets/css/tambahan.css?v=' . time()) ?>" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>
    <div>
        <a href="javascript:history.go(-1)">
            <button type="button" class="btn-close ms-3 mt-3" aria-label="Close"></button>
        </a>
    </div>
    <hr class="border-3">
    <div class="container">
        <?= form_open_multipart('guru/BuatTugas'); ?>
        <input type="hidden" name="id_kelas" value="<?= $this->session->userdata('kelas')['id_kelas']; ?>">
        <div class="row">
            <div class="col-sm-8 card p-4 mb-3 border-success border-3">
                <div class="my-3 form-group form-floating">
                    <input type="text" class="form-control" id="judul_tugas" name="judul_tugas" placeholder="Nama Kelas" required>
                    <label for="nama_kelas">Judul</label>
                </div>
                <div class="my-3 form-group form-floating">
                    <textarea class="form-control" id="petunjuk" name="petunjuk" placeholder="Mata Pelajaran" style="height: 100px" required></textarea>
                    <label for="mata_pelajaran">Petunjuk</label>
                </div>
            </div>
            <div class="col-3 card p-4 mb-3 ms-5 border-success border-3">
                <div class="my-3 form-group form-floating">
                    <input type="text" class="form-control" id="poin" name="poin" placeholder="Poin" required>
                    <label for="poin">Poin</label>
                </div>
                <div class="my-3 form-group form-floating">
                    <input type="datetime-local" class="form-control" id="tenggat_waktu" name="tenggat_waktu" required>
                    <label for="tenggat_waktu">Tenggat Waktu</label>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-8 card p-4 border-success border-3">
                <h5 class="mb-4">Lampiran</h5>
                <div class="row">
                    <div class="col">
                    </div>
                </div>
                <div class="row w-25 mt-5">
                    <label class="col btn btn-success rounded-pill fs-5 mx-2">
                        <input type="file" class="form-control" id="upload" name="upload[]" accept="image/*,.doc, .docx, .xls, .xlsx, .ppt, .pptx, .pdf" style="display: none;" multiple>
                        <i class="fa-solid fa-upload me-2"></i>
                        Upload
                    </label>
                </div>
            </div>
        </div>
        <div class="mt-1">
            <button class="btn btn-success fs-5 px-4" type="submit">BUAT</button>
        </div>
        <?= form_close(); ?>
    </div>
</body>

</html>