<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<html>

<head>
    <link rel="shortcut icon" href="<?php echo base_url('assets\image\mini-logo.png') ?>">
    <title><?= $title; ?></title>
    <link href="<?php echo base_url('https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js') ?>" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous">
    <link href="<?php echo base_url('https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js') ?>" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous">
    <link href="<?php echo base_url('assets\css\bootstrap.min.css') ?>" rel="stylesheet">
    <link href="<?php echo base_url('assets\js\bootstrap.bundle.min.js') ?>" rel="stylesheet">
    <link href="<?= base_url('assets\css\tambahan.css?v=' . time()) ?>" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>

</head>

<body>
    <!-- start navbar -->

    <nav class="navbar fixed-top navbar-expand-lg shadow-sm" style="height: 72px; background-color: #FFF;">
        <div class="container-fluid">
            <a class="navbar-brand" href="beranda">&nbsp;&nbsp;&nbsp;&nbsp;
                <img src="<?= base_url("assets\image\LOGO.png") ?>" alt="StarAcademy" height="35" style="">
            </a>
            <div>
                <a class="btn btn-join fs-4" data-bs-toggle="modal" data-bs-target="#exampleModal">
                    <i class="fa-fw fa-solid fa-plus"></i>
                </a>
                <span class="dropdown">
                    <button class="btn" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fa-regular fa-circle-user fa-fw fs-1" style="color:#217756"></i>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end" style="width: 500px; height: 300px;">
                        <div>
                            <h4 class="text-center">Halo, <?= $user['username']; ?></h4>
                        </div>
                        <div>
                            <li><a type="button" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#exampleModal1">Edit Profile</a></button></li>
                            <li><a type="button" class="dropdown-item btn btn-danger" style="color: red;" href="<?= base_url('auth/keluar') ?>">Keluar</a></li>
                        </div>
                    </ul>
                </span>
            </div>
            <!-- Button trigger modal -->
        </div>
    </nav>
    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="d-flex justify-content-end">
                    <button type="button" class=" btn-close mt-3 me-3" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <h3 class="text-center">Buat Kelas</h3>
                    <form action="<?= base_url('guru/BuatKelas'); ?>" method="POST" class="needs-validation" novalidate>
                        <div class="my-3 form-group form-floating">
                            <input type="text" class="form-control" id="nama_kelas" name="nama_kelas" placeholder="Nama Kelas"></input>
                            <label for="nama_kelas">Nama Kelas</label>
                        </div>
                        <div class="my-3 form-group form-floating">
                            <input type="text" class="form-control" id="mata_pelajaran" name="mata_pelajaran" placeholder="Mata Pelajaran"></input>
                            <label for="mata_pelajaran">Mata Pelajaran</label>
                        </div>
                        <div class="text-center">
                            <button class="btn btn-success px-3 py-2" type="submit"> BUAT</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Edit Profile -->
    <div class="modal fade" id="exampleModal1" tabindex="-1" aria-labelledby="exampleModalLabel1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="d-flex justify-content-end">
                    <button type="button" class=" btn-close mt-3 me-3" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <h3 class="text-center">Edit Profile</h3>
                    <?= form_open_multipart('guru/edit'); ?>
                    <div class="mb-3">
                        <label for="recipient-name" class="col-form-label">ID Guru</label>
                        <input type="text" class="form-control" id="id_user" name="id_user" value="<?= $user['id_user']; ?>" readonly>
                    </div>
                    <div class="mb-3">
                        <label for="recipient-name" class="col-form-label">Username</label>
                        <input type="text" class="form-control" id="username" name="username" value="<?= $user['username']; ?>">
                        <?= form_error('username', '<small class="text-danger ms-2">', '</small>'); ?>
                    </div>
                    <div class="mb-3 text-end">
                        <button type="submit" class="btn btn-success">Simpan Perubahan</button>
                    </div>

                    </form>

                </div>
            </div>
        </div>
    </div>


    </div>

    <script>
        btnJoin = document.querySelectorAll('.btn-join');

        btnJoin.forEach(element => {
            element.onclick = () => {
                document.getElementById('kode').value = ''
            }
        });
        window.onload = () => {
            document.getElementById('kode').value = ''
        }
    </script>


    <!-- end navbar -->