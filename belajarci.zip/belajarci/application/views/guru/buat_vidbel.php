<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<html>

<head>
    <link rel="shortcut icon" href="<?php echo base_url('assets\image\mini-logo.png') ?>">
    <title><?= $title; ?></title>
    <link href="<?php echo base_url('https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js') ?>" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous">
    <link href="<?php echo base_url('https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js') ?>" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous">
    <link href="<?php echo base_url('assets\css\bootstrap.min.css') ?>" rel="stylesheet">
    <link href="<?php echo base_url('assets\js\bootstrap.bundle.min.js') ?>" rel="stylesheet">
    <link href="<?= base_url('assets\css\tambahan.css?v=' . time()) ?>" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>

</head>


<body>
    <div>
        <a href="javascript:history.go(-1)">
            <button type="button" class="btn-close ms-3 mt-3" aria-label="Close"></button>
        </a>
    </div>
    <hr class="border-3">
    <div class="container">
        <?= form_open_multipart('guru/BuatVidbel'); ?>
        <input type="hidden" name="id_kelas" value="<?= $this->session->userdata('kelas')['id_kelas']; ?>">

        <div class="col-12 card p-4 mb-3 border-success border-3">
            <div class="my-3 form-group form-floating">
                <input type="text" class="form-control" id="judul_vidbel" name="judul_vidbel" placeholder="Nama Kelas" required>
                <label for="nama_kelas">Judul</label>
            </div>

            <!-- Display File Names -->
            <!-- Display File Names -->
            <div class="card" style="height:300px; display: flex; flex-direction: column; align-items: center; justify-content: center;">
                <div id="file-names" style="display: none;"></div>
                <div id="uploaded-videos"></div>
            </div>
            <div class="mt-3">
                <div class="dropdown">
                    <button class="btn" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <a id="upload-button" class="btn btn-success" style="text-decoration:none;">
                            <i class="fa-solid fa-upload"></i> Upload
                        </a>
                    </button>
                    <ul class="dropdown-menu">
                        <div>
                            <li>
                                <label class="dropdown-item">
                                    <input type="file" class="form-control" id="lampiran" style="display: none;" name="lampiran[]" onchange="updateFileName()" accept="video/*" multiple>
                                    Pilih File
                                </label>
                            </li>
                            <li>
                                <a class="dropdown-item" data-bs-toggle="modal" data-bs-target="#videoLinkModal">Link</a>
                            </li>
                        </div>
                    </ul>
                </div>
            </div>


            <div class="mt-1">
                <button class="btn btn-success fs-5 px-4" type="submit">BUAT</button>
            </div>
            </form>
        </div>

        <!-- Video Link Modal -->
        <div class="modal fade" id="videoLinkModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Input Video Link</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="video-link" class="col-form-label">Video Link:</label>
                            <input type="text" class="form-control" id="video-link" name="video-link" placeholder="Enter the video link">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary" id="addLinkBtn">Add Link</button>
                    </div>
                </div>
            </div>
        </div>

        <script>
            function updateFileName() {
                const fileInput = document.getElementById('lampiran');
                const fileNamesDiv = document.getElementById('file-names');
                const uploadedVideosDiv = document.getElementById('uploaded-videos');
                const uploadButton = document.getElementById('upload-button');

                // Clear previous content
                fileNamesDiv.innerHTML = '';
                uploadedVideosDiv.innerHTML = '';

                // Display selected file names
                for (const file of fileInput.files) {
                    const fileNameElement = document.createElement('div');
                    fileNameElement.innerText = file.name;
                    fileNamesDiv.appendChild(fileNameElement);

                    // Display the uploaded videos
                    const videoElement = document.createElement('video');
                    videoElement.width = 400;
                    videoElement.height = 300;
                    videoElement.controls = true;

                    // Create a source element for the video
                    const sourceElement = document.createElement('source');
                    sourceElement.src = URL.createObjectURL(file);
                    sourceElement.type = 'video/mp4'; // You may need to adjust the type based on your video format

                    // Append the source element to the video element
                    videoElement.appendChild(sourceElement);

                    // Append the video element to the uploadedVideosDiv
                    uploadedVideosDiv.appendChild(videoElement);
                }

                // Hide the upload button
            }

            function addVideoLink() {
                const videoLinkInput = document.getElementById('video-link').value;
                const uploadedVideosDiv = document.getElementById('uploaded-videos');

                // Clear previous content
                uploadedVideosDiv.innerHTML = '';

                // Display the video from the link
                const videoElement = document.createElement('video');
                videoElement.id = 'linkedVideo'; // Add an id for the video element
                videoElement.width = 400;
                videoElement.height = 300;
                videoElement.controls = true; // Enable playback controls

                // Create a source element for the video
                const sourceElement = document.createElement('source');
                sourceElement.src = videoLinkInput;
                sourceElement.type = 'video/mp4'; // You may need to adjust the type based on your video format

                // Append the source element to the video element
                videoElement.appendChild(sourceElement);

                // Append the video element to the uploadedVideosDiv
                uploadedVideosDiv.appendChild(videoElement);
            }

            // Use the correct ID for the button in the script
            document.getElementById('addLinkBtn').addEventListener('click', addVideoLink);
        </script>

    </div>
</body>


</html>