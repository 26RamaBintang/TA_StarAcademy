<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<html>

<head>
    <link rel="shortcut icon" href="<?php echo base_url('assets\image\mini-logo.png') ?>">
    <title><?= $title; ?></title>
    <link href="<?php echo base_url('https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js') ?>" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous">
    <link href="<?php echo base_url('https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js') ?>" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous">
    <link href="<?php echo base_url('assets\css\bootstrap.min.css') ?>" rel="stylesheet">
    <link href="<?php echo base_url('assets\js\bootstrap.bundle.min.js') ?>" rel="stylesheet">
    <link href="<?= base_url('assets\css\tambahan.css?v=' . time()) ?>" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>

</head>

<body>
    <div>
        <a href="javascript:history.go(-1)">
            <button type="button" class="btn-close ms-3 mt-3" aria-label="Close"></button>
        </a>
    </div>
    <hr class="border-3">
    <div class="container">
        <!-- Your form content here -->

        <script>
            function updateFileName() {
                const fileName = document.getElementById('lampiran_file').files[0].name;
                document.getElementById('file-name').innerText = fileName;
            }
        </script>

    </div>
    <div class="container">
        <form action="<?= base_url('guru/edit_tugas/' . $existing_task['id_tugas']); ?>" method="POST" class="needs-validation" novalidate>
            <input type="hidden" name="id_kelas" value="<?= $this->session->userdata('kelas')['id_kelas']; ?>">
            <div class="row">
                <div class="col-sm-8 card p-4 mb-3 border-success border-3">
                    <div class="my-3 form-group form-floating">
                        <input type="text" class="form-control" id="judul_tugas" name="judul_tugas" placeholder="judul " value="<?=$existing_task['judul_tugas']; ?>" required>
                        <label for="judul">Judul</label>
                    </div>
                    <div class="my-3 form-group form-floating">
                        <textarea class="form-control" id="petunjuk" name="petunjuk" placeholder="petunjuk" style="height: 100px" required><?=$existing_task['petunjuk']; ?></textarea>
                        <label for="petunjuk">Petunjuk</label>
                    </div>
                </div>
                <div class="col-3 card p-4 mb-3 ms-5 border-success border-3">
                    <div class="my-3 form-group form-floating">
                        <input type="text" class="form-control" id="poin" name="poin" placeholder="Poin" value="<?=$existing_task['poin']; ?>" required>
                        <label for="poin">Poin</label>
                    </div>
                    <div class="my-3 form-group form-floating">
                        <input type="datetime-local" class="form-control" id="tenggat_waktu" name="tenggat_waktu" value="<?=$existing_task['tenggat']; ?>" required>
                        <label for="tenggat_waktu">Tenggat Waktu</label>
                    </div>

                </div>
            </div>
            <div class="row ">
                <div class="col-sm-8 card p-4 border-success border-3">
                    <h5 class="mb-4">Lampiran</h5>

                    <!-- Tombol Upload File 1 -->
                    <div class="row w-50">
                        <label class="col btn btn-success w-100 rounded-pill fs-5 mx-2">
                            <input type="file" class="form-control" id="lampiran" name="lampiran" style="display: none;" onchange="updateFileName()">
                            <i class="fa-solid fa-upload me-2"></i>
                            Upload
                        </label>

                        <!-- Tombol Upload File 2 -->
                        <label class="col btn btn-success w-100 rounded-pill fs-5 mx-2">
                            <input type="file" class="form-control" id="lampiran" name="lampiran" style="display: none;" onchange="updateFileName()">
                            <i class="fa-solid fa-upload me-2"></i>
                            Upload
                        </label>
                    </div>

                    <!-- Tombol Upload Link -->
                </div>
            </div>


            <div class="mt-1">
                <button class="btn btn-success fs-5 px-4" type="submit"><?= ($existing_task !== null) ? 'UBAH' : 'EDIT'; ?></button>
            </div>
        </form>
    </div>

    <script>
        function updateFileName() {
            const fileName = document.getElementById('lampiran_file').files[0].name;
            document.getElementById('file-name').innerText = fileName;
        }
    </script>

    </div>
</body>

</html>