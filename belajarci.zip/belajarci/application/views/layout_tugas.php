<html>

<head>
    <link rel="shortcut icon" href="<?php echo base_url('assets\image\mini-logo.png') ?>">
    <title>Tugas | StarAcademy</title>
    <link href="<?php echo base_url('https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js') ?>" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous">
    <link href="<?php echo base_url('https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js') ?>" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous">
    <link href="<?php echo base_url('assets\css\bootstrap.min.css') ?>" rel="stylesheet">
    <link href="<?= base_url('assets\css\tambahan.css?v=' . time()) ?>" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

</head>

<body>
    <!-- start navbar -->

    <nav class="navbar fixed-top navbar-expand-lg bg-body-tertiary shadow-sm" style="height: 72px; background-color: #FFF;">
        <div class="container-fluid">
            <a class="navbar-brand" href="beranda">&nbsp;&nbsp;&nbsp;&nbsp;
                <img src="<?= base_url("assets\image\LOGO.png") ?>" alt="StarAcademy" height="35" style="">
            </a>
            <div>
                <span class="fa-regular fa-circle-user"></span>&nbsp;&nbsp;
            </div>
        </div>
    </nav>

    <!-- end navbar -->