<!-- form -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
<div class="container kontener shadow">
    <form action="<?= base_url('auth'); ?>" method="POST" class="needs-validation" novalidate>
        <br>
        <h2 class="masuk mb-4 text-center">MASUK</h2>

        <?= $this->session->flashdata('notif') ?>

        <div class="my-3 form-floating">
            <input type="text" class="form-control" id="username" name="username" placeholder="Username" value="<?= set_value('username'); ?>" required></input>
            <label for="username">Username</label>
            <div class="invalid-feedback ms-2">
                Masukkan Username Anda
            </div>
        </div>
        <div class="my-3  form-floating">
            <input type="password" class="form-control" id="passwd" name="passwd" placeholder="Password" required>
            <label for="passwd">Password</label>
            <div class="invalid-feedback ms-2">
                Masukkan Password Anda
            </div>
        </div>
        <div class="text-center">
            <button class="btn btn-success button my-3" type="submit">MASUK</button>
            <p class="mt-4" style="font-size: 15px;">Belum Menjadi Anggota?
                <a href="<?= base_url('auth/daftar'); ?>">Daftar Sekarang</a>

            </p>
        </div>
    </form>

</div>