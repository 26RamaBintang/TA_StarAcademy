<!-- form -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
<div class="container kontener shadow">
    <form action="<?= base_url('auth/daftar'); ?>" method="POST" class="needs-validation" novalidate>
        <br>
        <h2 class="masuk mb-4 text-center">DAFTAR</h2>
        <div class="my-3 form-floating">
            <input type="text" class="form-control" id="username" name="username" placeholder="Username" value="<?= set_value('username'); ?>" required></input>
            <?= form_error('username', '<small class="text-danger ms-2">', '</small>'); ?>
            <label for="username">Username</label>
            <div class="invalid-feedback ms-2">
                Silahkan Masukkan Username
            </div>
        </div>
        <div class="my-3  form-floating">
            <input type="password" class="form-control" id="passwd1" name="passwd1" placeholder="Password" required>
            <?= form_error('passwd1', '<small class="text-danger ms-2">', '</small>'); ?>
            <label for="passwd1">Password</label>
            <div class="invalid-feedback ms-2">
                Silahkan Masukkan Sebuah Password
            </div>
        </div>
        <div class="my-3 form-floating">
            <input type="password" class="form-control" id="passwd2" name="passwd2" placeholder="Konfirmasi Passsword" required>
            <?= form_error('passwd2', '<small class="text-danger ms-2">', '</small>'); ?>
            <label for="passwd2">Konfirmasi Password</label>
            <div class="invalid-feedback ms-2">
                Silahkan Konfirmasi Password Anda
            </div>
        </div>
        <div class="input-group my-3">
            <label class="input-group-text" for="level">Status</label>
            <select class="form-select" id="level" name="status" required>
                <option disabled selected hidden value=""></option>
                <option value="Guru">Guru</option>
                <option value="Siswa">Siswa</option>
            </select>
            <div class="invalid-feedback ms-2">
                Silahkan Pilih Status Anda
            </div>
        </div>
        <div class="text-center">
            <button class="btn btn-success button my-3" type="submit">DAFTAR</button>
            <p style="font-size: 15px;">Sudah Menjadi Anggota?
                <a href="<?= base_url('auth'); ?>">Masuk Sekarang</a>
            </p>
        </div>
    </form>
</div>